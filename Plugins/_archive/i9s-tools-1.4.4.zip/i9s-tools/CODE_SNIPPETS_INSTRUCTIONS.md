# Code Snippets for Task C - Career Totals

These snippets must be manually added to WordPress via Code Snippets plugin.

See full instructions in the file...
